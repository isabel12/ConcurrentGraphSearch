import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.Collections;


public class Search {
	static String directory = "C:\\Users\\Izzi\\Documents\\Uni\\NWEN303\\Project1\\";

	protected Map<Integer, Node> nodes;
	protected Set<Integer> goals;
	protected int start;

	protected HashMap<Integer, String> foundCycles;

	protected long startTime;
	protected long stopTime;

	public Search(String filename){
		FileReader reader = new FileReader();
		reader.ReadFile(directory + filename);
		this.nodes = reader.getNodes();
		this.goals = reader.getGoals();
		this.start = reader.getStart();	
	}

	public void PrintResults(){
		System.out.println(String.format("Time taken: %dms", (int)(stopTime-startTime)));
		
		// get all answers
		List<String> answers = new ArrayList<String>();
		for(Node n: nodes.values()){
			for(String answer: n.GetAnswers()){
				answers.add(answer);
			}
		}

		System.out.println("NumAnswers: " + answers.size());
		
		// add in the cycles
		//--------------------------------------
		for(int i = 0; i < answers.size(); i++){
			String scannedAnswer = answers.get(i);		
			Scanner scan = new Scanner(scannedAnswer);

			Set<String> containedCycles = new HashSet<String>();
			String actualAnswer = scannedAnswer;
			while(scan.hasNextInt()){
				int nextNode = scan.nextInt();

				// go through each node in the answer, and get the cycles beginning with each node
				if(foundCycles.containsKey(nextNode)){

					String cycleString = foundCycles.get(nextNode);

					// add the cycles in if they aren't already contained
					if(!CycleUsed(cycleString, containedCycles)){

						// insert it into the answer
						int nodeIndex = actualAnswer.indexOf(nextNode + " ");  // it will always be at most once with a space after it.
						if(nodeIndex > -1){
							String firstHalf = actualAnswer.substring(0, nodeIndex);
							String secondHalf = actualAnswer.substring(nodeIndex + 2);
							actualAnswer = firstHalf + nextNode + " " + cycleString + " " + secondHalf;			
						}

						// record that we have used it
						containedCycles.add(cycleString);	
					}
				}
			}

			// add in the new answer
			answers.remove(i);
			answers.add(i, actualAnswer);	
		}

		// print complete answers
		//---------------------------------
		for(String answer: answers){
			System.out.println(answer);
		}
	}


	public static boolean CycleUsed(String cycle1, Set<String> containedCycles){

		String[] cycle1Array = cycle1.split("[()*,]");
		List<String> cycle1List = new ArrayList<String>();
		for(int i = 0; i < cycle1Array.length; i++){
			cycle1List.add(cycle1Array[i]);
		}
		Collections.sort(cycle1List);

		for(String cycle2: containedCycles){

			String[] cycle2Array = cycle2.split("[()*,]");

			if(cycle1Array.length != cycle2Array.length){
				return false;
			}

			List<String> cycle2List = new ArrayList<String>();
			for(int i = 0; i < cycle2Array.length; i++){
				cycle2List.add(cycle2Array[i]);
			}
			Collections.sort(cycle2List);

			for(int i = 0; i < cycle1List.size(); i++){
				if(!cycle1List.get(i).equals(cycle2List.get(i))){
					continue;
				}
			}
			return true;
		}

		return false;
	}

}
