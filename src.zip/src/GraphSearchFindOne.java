import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public class GraphSearchFindOne extends Search {

	private static String filename = "CyclicGraph2.txt";

	private Object answerLock = new Object();
	private Object cycleLock = new Object();
	
	
	private boolean found;
	
	public GraphSearchFindOne() {
		super(filename);
		foundCycles = new HashMap<Integer, String>();
	}

	public void Search(){	
		startTime = System.currentTimeMillis();	
		// create a new thread
		Thread thread = new SearchThread("", nodes.get(this.start), new HashSet<Integer>());	
		// start
		thread.start();		
		// wait to finish
		try {
			thread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}		
		stopTime = System.currentTimeMillis();

		PrintResults();
	}

	public class SearchThread extends Thread{
		Node node;
		String pathToNode;
		int nodeId;
		Set<Integer> visited;

		public SearchThread(String pathToParent, Node n, Set<Integer> visited){
			this.nodeId = n.GetId();
			this.pathToNode = pathToParent + nodeId + " ";
			this.node = n;
			this.visited = new HashSet<Integer>(visited);
		}
		
		@Override
		public void run() {
			SearchRec();
		}

		public void SearchRec(){
			// check if the answer has been found
			if(found){
				return;
			}
			
			// check for a cycle
			if(visited.contains(nodeId)){
				DealWithCycle(pathToNode, nodeId);
				return;
			}

			// visit
			visited.add(nodeId);

			// see if we are at a goal
			if(goals.contains(nodeId)){	
				synchronized(answerLock){
					if(!found){
						node.AddAnswer(pathToNode);
						found = true;
					}
					return;
				}
			}

			// spawn a new thread for each child search
			Set<Thread> childThreads = new HashSet<Thread>();
			for(Node child: node.GetChildren()){
				Thread childThread = new SearchThread(pathToNode, child, visited);
				childThreads.add(childThread);
				childThread.start();
			}	

			// wait for all children to finish
			try {
				for(Thread childThread: childThreads){
					if(childThread.isAlive()){
						childThread.join();
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private void DealWithCycle(String pathToNode, int nodeId){
		int startIndex = pathToNode.indexOf(nodeId + "");
		String cycle = String.format("(%s)*", pathToNode.substring(startIndex + 1).trim());	
		cycle = cycle.replace(" ", ",");

		synchronized(cycleLock){
			String cycles = foundCycles.get(nodeId);
			if(cycles == null){
				cycles = "";
			}
	
			if(!cycles.contains(cycle)){
				foundCycles.put(nodeId, cycles + cycle);	
			}
		}
	}
	
	public static void main(String[] args){
		new GraphSearchFindOne().Search();
	}

}
