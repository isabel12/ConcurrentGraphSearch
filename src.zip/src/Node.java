import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Node{
	private int id;
	private Set<Node> children;
	private Set<Node> parents;
	private List<String> answers;

	public Node(int id){
		this.id = id;
		this.children = new HashSet<Node>();
		this.parents = new HashSet<Node>();
		this.answers = new ArrayList<String>();
	}

	public void AddParent(Node p){
		parents.add(p);
	}

	public void AddChild(Node c){
		children.add(c);
	}

	public Set<Node> GetChildren(){
		return children;
	}

	public Set<Node> GetParents(){
		return parents;
	}

	public int GetId(){
		return id;
	}

	public synchronized void AddAnswer(String answer){
		this.answers.add(answer);
	}

	public List<String> GetAnswers(){
		return new ArrayList<String>(answers);
	}
}